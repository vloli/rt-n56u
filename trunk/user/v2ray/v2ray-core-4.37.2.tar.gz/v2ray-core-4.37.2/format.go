package core

//go:generate go install -v golang.org/x/tools/cmd/goimports@latest
//go:generate go run ./infra/vformat/
