package conf_test

const (
	geoipURL   = "https://raw.githubusercontent.com/v2fly/geoip/release/geoip.dat"
	geositeURL = "https://raw.githubusercontent.com/v2fly/domain-list-community/release/dlc.dat"
)
